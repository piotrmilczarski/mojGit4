/** Automatically generated file. DO NOT MODIFY */
package pl.uni.mojgit3ecl;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}